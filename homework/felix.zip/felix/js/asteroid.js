export default class Asteroid {
    constructor(img, x, y) {
        this.img = img;
        this.x = x;
        this.y = y;
    }
}