export default class ResourcePlanet {
    constructor(img, x, y) {
        this.img = img;
        this.x = x;
        this.y = y;
    }
    draw(ctx) {

    }
}